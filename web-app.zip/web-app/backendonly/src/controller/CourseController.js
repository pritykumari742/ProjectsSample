const express = require("express"); 
const myCourseRoute = express.Router(); 
 
let MyCourse = require("../model/Course"); 
 
// Get All Courses 
myCourseRoute.route("/courses").get( 
    (req, res) => { 
    console.log("/courses ---get()");    
    MyCourse.find((error, data) => {   

         if (error) { 
        return next(error); 
      } else {         
          res.json(data); 
      } 
    }).sort({ bookId: 1 }); //start and book id 1
  }); 
   
  // Get Course By Id 
  myCourseRoute.route("/courses/:courseId").get((req, res, next) => {   
      console.log("/courses/:courseId --- get()"); 
  MyCourse.findOne(
      { courseId: req.params.courseId }, 
      (error, data) => {       
          if (error) { 
        return next(error); 
      } else {         
        res.json(data); 
      } 
    }); 
  }); 
   
  module.exports = myCourseRoute; 
 
