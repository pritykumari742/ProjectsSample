const mongoose = require("mongoose"); 
const Schema = mongoose.Schema; 
 
// Define collection and schema 
let MyCourse = new Schema( 
  { 
    courseId: { type: String },     
    courseName: { type: String },     
    duration: { type: String },     
    trainer: { type: String }, 
    enrollments: { type: Number }, 
  }, 
  { timestamps: true, collection: "courses" } //collection name courses
); 
module.exports = mongoose.model("MyCourse", MyCourse); 
