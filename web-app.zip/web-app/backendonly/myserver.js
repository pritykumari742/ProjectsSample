const express = require("express"); 
const bodyParser = require("body-parser"); 
const dotenv = require("dotenv"); 
const mongoose = require("mongoose"); 
//const path = require("path"); 
const cors = require("cors"); 

 

/** 
*	Load environment variables from .env.jlc file. 
 */ 
dotenv.config({ path: ".env.jlc" });

mongoose.connect(process.env.MONGODB_URI, { 
    useUnifiedTopology: true,      
    useNewUrlParser: true,
    
  }) 
  .then( 
    () => { 
      console.log("MongoDB connected successfully."); 
    }, 
    (error) => {      
         console.error(error);       console.log( 
        "MongoDB connection error. Please make sure MongoDB is running." 
      ); 
      process.exit(); 
    } 
  ); 

 

/** 
*	Add middlewares 
 */ 
const app = express(); 
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: false })); 
app.use(cors()); 
 
const myCourseController = require("./src/controller/CourseController"); 
 
app.use("/myapi/", myCourseController); 
 
/** 

/** 
*	Set Response for requestURI - /ping 
 */ 
app.get("/hello", (req, res) => {   console.log("Request for - /hello"); 
   return res.send("Hello Guys -- I am Ready"); 
}); 
 

 
/** 
*	start Express server on port 5300 
 */ 
const PORT = process.env.PORT || 5300; 
app.listen(PORT, () => { 
  console.log("Express server is running at http://localhost:%d", PORT);   
  console.log("Press CTRL-C to stop\n"); 
}); 
