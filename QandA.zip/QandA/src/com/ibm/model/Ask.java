package com.ibm.model;

public class Ask {
	
	String username;
	String question;
	String details;
	String date;
	String totans;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTotans() {
		return totans;
	}
	public void setTotans(String totans) {
		this.totans = totans;
	}

}
