cont stars=document.querySelectorAll('.star');
const output=document.querySelector('.output');
for(x=0;x<stars.length;x++){
  stars[x].starValue=(x+1);
//stars[x].addEventListener('click', function(){
 // console.log("i am click");
//}
//)
["click", "mouseover","mouseout"].forEach(function(e){
  stars[x].addEventListener(e, showRating);
})
}
function showRating(e){
  let type=e.type;
  let starValue=this.starValue;
  //console.log(startValue);
  stars.forEach(function(elen, ind){
    if(type=== 'click'){
      if(ind< starValue){
        elem.classList.add("orange");
      }else{
        elem.classList.remove("orange");
      }
    }
  })
}